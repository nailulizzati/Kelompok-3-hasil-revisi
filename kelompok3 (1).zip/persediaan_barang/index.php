<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Aplikasi Persediaan Barang</title>
    <link rel="icon" href="https://getbootstrap.com/docs/5.0/assets/img/favicons/favicon.ico">

    <!-- Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  
  <body>
    <!-- Panggilan File menu.php -->
    <?php require_once('menu.php'); ?>

    <!-- Konten Utama -->
    <div class="container mt-5">
      <div class="jumbotron p-5 text-center bg-light rounded">
        <h1 class="display-4">Aplikasi Persediaan Barang</h1>
        <p class="lead">Aplikasi mudah belajar PHP Dasar dengan Database MySQL.</p>
      </div>
    </div>

    <!-- Bootstrap 5 JS Bundle (Includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
