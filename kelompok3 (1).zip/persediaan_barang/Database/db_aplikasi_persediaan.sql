-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2025 at 03:41 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_aplikasi_persediaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_barang`
--

CREATE TABLE `tb_barang` (
  `kode_barang` varchar(50) NOT NULL,
  `nama` varchar(250) DEFAULT NULL,
  `harga_beli` int(11) DEFAULT 0,
  `harga_jual` int(11) DEFAULT 0,
  `stok` int(11) DEFAULT 0,
  `satuan` varchar(50) DEFAULT NULL,
  `petugas` varchar(50) DEFAULT NULL,
  `kode_supplier` varchar(50) NOT NULL,
  `jenis` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_barang`
--

INSERT INTO `tb_barang` (`kode_barang`, `nama`, `harga_beli`, `harga_jual`, `stok`, `satuan`, `petugas`, `kode_supplier`, `jenis`) VALUES
('BRG01', 'Kopi Robusta', 180, 300, 291, 'KG', 'ADMIN', 'AGH', 'Spesial'),
('BRG02', 'kopi Biasa', 100, 200, 143, 'KG', 'ADMIN', 'AGH', 'Biasa'),
('BRG03', 'Kopi Aceh Anaerob', 250, 300, 193, 'KG', 'ADMIN', 'AGH', 'Spesial'),
('BRG04', 'Gayo Land Coffe', 200, 300, 71, 'KG', 'ADMIN', 'AGH', 'Spesial'),
('BRG05', 'Arabika Specialty', 300, 400, 91, 'KG', 'ADMIN', 'BCL', 'Promo');

-- --------------------------------------------------------

--
-- Table structure for table `tb_barang_keluar`
--

CREATE TABLE `tb_barang_keluar` (
  `id` int(11) NOT NULL,
  `tanggal` datetime DEFAULT NULL,
  `kode_pelanggan` varchar(50) DEFAULT NULL,
  `kode_barang` varchar(50) DEFAULT NULL,
  `nama` varchar(250) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `satuan` varchar(50) DEFAULT NULL,
  `petugas` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_barang_keluar`
--

INSERT INTO `tb_barang_keluar` (`id`, `tanggal`, `kode_pelanggan`, `kode_barang`, `nama`, `jumlah`, `satuan`, `petugas`) VALUES
(3, '2024-12-01 15:17:52', 'PLG001', 'BRG04', NULL, 11, NULL, 'Admin'),
(4, '2024-12-01 15:19:05', 'PLG002', 'BRG05', NULL, 18, NULL, 'Admin'),
(5, '2024-12-01 15:19:20', 'PLG004', 'BRG03', NULL, 111, NULL, 'Admin'),
(6, '2025-01-19 15:39:27', 'PLG002', 'BRG05', NULL, 158, NULL, 'Admin'),
(7, '2025-01-19 15:39:54', 'PLG003', 'BRG04', NULL, 250, NULL, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `tb_barang_masuk`
--

CREATE TABLE `tb_barang_masuk` (
  `id` int(11) NOT NULL,
  `tanggal` datetime DEFAULT NULL,
  `kode_supplier` varchar(50) DEFAULT NULL,
  `kode_barang` varchar(50) DEFAULT NULL,
  `nama` varchar(250) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `satuan` varchar(50) DEFAULT NULL,
  `petugas` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_barang_masuk`
--

INSERT INTO `tb_barang_masuk` (`id`, `tanggal`, `kode_supplier`, `kode_barang`, `nama`, `jumlah`, `satuan`, `petugas`) VALUES
(11, '2024-11-29 15:14:18', 'AGH', 'BRG01', NULL, 133, NULL, 'Win Aritanoga'),
(13, '2024-11-29 15:34:09', 'TAC', 'BRG01', NULL, 13, NULL, 'Anton'),
(14, '2024-11-29 15:34:38', 'TK', 'BRG02', NULL, 18, NULL, 'Firmansyah'),
(15, '2024-11-29 15:34:58', 'TAC', 'BRG03', NULL, 18, NULL, 'Friska Laguna'),
(16, '2024-11-29 15:35:23', 'TLC', 'BRG04', NULL, 181, NULL, 'Firmansyah'),
(17, '2024-11-29 15:35:40', 'TAC', 'BRG05', NULL, 151, NULL, 'Win sibensu');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan` (
  `kode_pelanggan` varchar(50) NOT NULL,
  `nama` varchar(250) DEFAULT NULL,
  `alamat` varchar(250) DEFAULT NULL,
  `telp` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`kode_pelanggan`, `nama`, `alamat`, `telp`) VALUES
('PLG001', 'Rike Simehate', 'JL.Warijy', '082365886531'),
('PLG002', 'Rita Ramadani', 'Kec. Pegasing', '0822375719051'),
('PLG003', 'Raihan Majid', 'Kec. Kebayakan', '089272364827'),
('PLG004', 'Birra Sidqi', 'Kec. Kebayakan', '0823747611728');

-- --------------------------------------------------------

--
-- Table structure for table `tb_petugas`
--

CREATE TABLE `tb_petugas` (
  `kode_petugas` varchar(50) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `jabatan` varchar(250) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_petugas`
--

INSERT INTO `tb_petugas` (`kode_petugas`, `nama`, `jabatan`, `password`) VALUES
('ADM', 'Firmansyah', 'ADMIN / OWNER', 'ADM'),
('AG', 'Khairis Sufiani', 'ADMIN GUDANG', 'AG'),
('SA', 'Deyah Apriyanda', 'SALES', 'SA'),
('SA1', 'Laili', 'SALES', 'SA1'),
('SPV', 'Nailul Izzati', 'SUPERVISOR', 'SPV');

-- --------------------------------------------------------

--
-- Table structure for table `tb_supplier`
--

CREATE TABLE `tb_supplier` (
  `kode_supplier` varchar(50) NOT NULL,
  `nama` varchar(250) DEFAULT NULL,
  `alamat` varchar(250) DEFAULT NULL,
  `telp` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_supplier`
--

INSERT INTO `tb_supplier` (`kode_supplier`, `nama`, `alamat`, `telp`) VALUES
('TAC', 'Toko Arabika Classic', 'jl. Putri Pukes', '082369015658'),
('TK', 'Toke Kopi', 'Paya Tumpi', '082369015658'),
('TLC', 'Toko Land Coffe', 'Jl.Warijy no.25 depan SD', '082369015658');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`kode_barang`) USING BTREE;

--
-- Indexes for table `tb_barang_keluar`
--
ALTER TABLE `tb_barang_keluar`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_kode_barang` (`kode_barang`) USING BTREE,
  ADD KEY `idx_kode_pelanggan` (`kode_pelanggan`) USING BTREE;

--
-- Indexes for table `tb_barang_masuk`
--
ALTER TABLE `tb_barang_masuk`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_kode_barang` (`kode_barang`) USING BTREE,
  ADD KEY `idx_kode_supplier` (`kode_supplier`) USING BTREE;

--
-- Indexes for table `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  ADD PRIMARY KEY (`kode_pelanggan`) USING BTREE;

--
-- Indexes for table `tb_petugas`
--
ALTER TABLE `tb_petugas`
  ADD PRIMARY KEY (`kode_petugas`) USING BTREE;

--
-- Indexes for table `tb_supplier`
--
ALTER TABLE `tb_supplier`
  ADD PRIMARY KEY (`kode_supplier`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_barang_keluar`
--
ALTER TABLE `tb_barang_keluar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_barang_masuk`
--
ALTER TABLE `tb_barang_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
